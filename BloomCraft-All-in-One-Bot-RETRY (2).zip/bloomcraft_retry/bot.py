import os
import discord
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()
TOKEN = os.getenv("DISCORD_TOKEN")
PREFIX = os.getenv("COMMAND_PREFIX", "!")
EXTENSIONS = [
    "cogs.general", "cogs.moderation", "cogs.welcome", "cogs.tickets",
    "cogs.leveling", "cogs.economy", "cogs.invites", "cogs.lifesteal",
    "cogs.minecraft", "cogs.boosts", "cogs.giveaways", "cogs.logs", "cogs.community", "cogs.roles", "cogs.music"
]

class BloomCraftBot(commands.Bot):
    async def setup_hook(self):
        for extension in EXTENSIONS:
            try:
                await self.load_extension(extension)
                print(f"Loaded {extension}")
            except Exception as exc:
                print(f"Could not load {extension}: {exc}")
        await self.tree.sync()
        print("Slash commands synced.")

intents = discord.Intents.default()
intents.guilds = True
intents.members = True
intents.message_content = True
intents.messages = True
intents.reactions = True

bot = BloomCraftBot(command_prefix=PREFIX, intents=intents)

@bot.event
async def on_ready():
    print(f"Logged in as {bot.user} (ID: {bot.user.id})")
    print(f"Connected to {len(bot.guilds)} servers.")

if not TOKEN:
    raise RuntimeError("Set DISCORD_TOKEN in your .env file before starting.")
bot.run(TOKEN)
