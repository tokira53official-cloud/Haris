import discord
from discord.ext import commands
from discord import app_commands
from config import connect

class Economy(commands.Cog):
    def __init__(self, bot): self.bot = bot
    def balance(self, guild_id, user_id):
        with connect() as db:
            row = db.execute("SELECT coins FROM wallets WHERE guild_id=? AND user_id=?", (guild_id,user_id)).fetchone()
            return row["coins"] if row else 0
    @app_commands.command(name="balance", description="Check your server-specific coin balance.")
    async def balance_cmd(self, interaction: discord.Interaction, member: discord.Member = None):
        member = member or interaction.user
        await interaction.response.send_message(f"💰 **{member.display_name}** has **{self.balance(interaction.guild_id,member.id)}** coins.")
    @app_commands.command(name="daily", description="Claim your daily coins (once per day).")
    async def daily(self, interaction: discord.Interaction):
        # Basic starter reward; production deployments should add a persisted cooldown.
        with connect() as db:
            db.execute("INSERT INTO wallets(guild_id,user_id,coins) VALUES(?,?,500) ON CONFLICT(guild_id,user_id) DO UPDATE SET coins=coins+500",
                       (interaction.guild_id,interaction.user.id))
        await interaction.response.send_message("🌸 You received **500 coins**!")
    @app_commands.command(name="pay", description="Give coins to another member.")
    async def pay(self, interaction: discord.Interaction, member: discord.Member, amount: app_commands.Range[int,1,1000000]):
        if member.bot or member.id == interaction.user.id:
            return await interaction.response.send_message("Choose another human member.", ephemeral=True)
        with connect() as db:
            sender = db.execute("SELECT coins FROM wallets WHERE guild_id=? AND user_id=?", (interaction.guild_id,interaction.user.id)).fetchone()
            if not sender or sender["coins"] < amount:
                return await interaction.response.send_message("Not enough coins.", ephemeral=True)
            db.execute("UPDATE wallets SET coins=coins-? WHERE guild_id=? AND user_id=?", (amount,interaction.guild_id,interaction.user.id))
            db.execute("INSERT INTO wallets(guild_id,user_id,coins) VALUES(?,?,?) ON CONFLICT(guild_id,user_id) DO UPDATE SET coins=coins+excluded.coins",
                       (interaction.guild_id,member.id,amount))
        await interaction.response.send_message(f"💸 Sent **{amount}** coins to {member.mention}.")

async def setup(bot): await bot.add_cog(Economy(bot))
