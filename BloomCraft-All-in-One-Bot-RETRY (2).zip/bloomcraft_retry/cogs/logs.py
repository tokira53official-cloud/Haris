import discord
from discord.ext import commands
from discord import app_commands
from config import get_setting, set_setting

class Logs(commands.Cog):
    def __init__(self, bot): self.bot = bot

    async def send_log(self, guild, embed):
        cid = get_setting(guild.id, "log_channel")
        channel = guild.get_channel(int(cid)) if cid else None
        if channel:
            try: await channel.send(embed=embed)
            except discord.HTTPException: pass

    @app_commands.command(name="setlogs", description="Set the server audit log channel.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setlogs(self, interaction: discord.Interaction, channel: discord.TextChannel):
        set_setting(interaction.guild_id, "log_channel", channel.id)
        await interaction.response.send_message(f"Logs will be sent to {channel.mention}.", ephemeral=True)

    @commands.Cog.listener()
    async def on_message_delete(self, message):
        if not message.guild or message.author.bot: return
        e = discord.Embed(title="🗑️ Message deleted", color=0xE57373)
        e.add_field(name="Author", value=f"{message.author} (`{message.author.id}`)", inline=False)
        e.add_field(name="Channel", value=message.channel.mention, inline=False)
        if message.content: e.add_field(name="Content", value=message.content[:1000], inline=False)
        await self.send_log(message.guild, e)

    @commands.Cog.listener()
    async def on_message_edit(self, before, after):
        if not before.guild or before.author.bot or before.content == after.content: return
        e = discord.Embed(title="✏️ Message edited", color=0xF4A7C5)
        e.add_field(name="Author", value=before.author.mention)
        e.add_field(name="Channel", value=before.channel.mention)
        e.add_field(name="Before", value=(before.content or "—")[:900], inline=False)
        e.add_field(name="After", value=(after.content or "—")[:900], inline=False)
        await self.send_log(before.guild, e)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        e = discord.Embed(title="👋 Member left", description=f"{member} (`{member.id}`)", color=0xE57373)
        await self.send_log(member.guild, e)

async def setup(bot): await bot.add_cog(Logs(bot))
