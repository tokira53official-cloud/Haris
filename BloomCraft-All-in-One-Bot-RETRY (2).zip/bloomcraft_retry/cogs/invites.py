import discord
from discord.ext import commands
from discord import app_commands
from config import connect

class Invites(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.cache = {}
    @commands.Cog.listener()
    async def on_ready(self):
        for guild in self.bot.guilds:
            try: self.cache[guild.id] = await guild.invites()
            except discord.Forbidden: pass
    @commands.Cog.listener()
    async def on_member_join(self, member):
        try:
            before = self.cache.get(member.guild.id, [])
            after = await member.guild.invites()
            used = next((i for i in after if i.uses > next((x.uses for x in before if x.code == i.code), 0)), None)
            self.cache[member.guild.id] = after
            if used and used.inviter:
                with connect() as db:
                    db.execute("INSERT INTO invites(guild_id,user_id,count) VALUES(?,?,1) ON CONFLICT(guild_id,user_id) DO UPDATE SET count=count+1",
                               (member.guild.id,used.inviter.id))
                await member.guild.system_channel.send(f"🎉 {member.mention} was invited by {used.inviter.mention}!") if member.guild.system_channel else None
        except (discord.Forbidden, discord.HTTPException): pass
    @app_commands.command(name="invites", description="Check invite count.")
    async def invites(self, interaction: discord.Interaction, member: discord.Member = None):
        member = member or interaction.user
        with connect() as db:
            row = db.execute("SELECT count FROM invites WHERE guild_id=? AND user_id=?", (interaction.guild_id,member.id)).fetchone()
        await interaction.response.send_message(f"🔗 {member.mention} has **{row['count'] if row else 0}** tracked invites.")

async def setup(bot): await bot.add_cog(Invites(bot))
