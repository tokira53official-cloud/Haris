import discord
from discord.ext import commands
from discord import app_commands

class General(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="ping", description="Check bot latency.")
    async def ping(self, interaction: discord.Interaction):
        await interaction.response.send_message(f"🏓 Pong! `{round(self.bot.latency*1000)}ms`")

    @app_commands.command(name="serverinfo", description="Show server information.")
    async def serverinfo(self, interaction: discord.Interaction):
        g = interaction.guild
        e = discord.Embed(title=f"🌸 {g.name}", color=0xF4A7C5)
        e.add_field(name="Members", value=g.member_count or "Unknown")
        e.add_field(name="Owner", value=g.owner.mention if g.owner else "Unknown")
        e.add_field(name="Created", value=discord.utils.format_dt(g.created_at, "D"))
        if g.icon: e.set_thumbnail(url=g.icon.url)
        await interaction.response.send_message(embed=e)

    @app_commands.command(name="userinfo", description="Show information about a member.")
    async def userinfo(self, interaction: discord.Interaction, member: discord.Member = None):
        member = member or interaction.user
        e = discord.Embed(title=f"User: {member}", color=0xF4A7C5)
        e.add_field(name="ID", value=member.id)
        e.add_field(name="Joined", value=discord.utils.format_dt(member.joined_at, "R") if member.joined_at else "Unknown")
        e.set_thumbnail(url=member.display_avatar.url)
        await interaction.response.send_message(embed=e)

async def setup(bot): await bot.add_cog(General(bot))
