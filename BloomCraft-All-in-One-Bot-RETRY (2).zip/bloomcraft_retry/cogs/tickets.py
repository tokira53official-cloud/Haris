import discord
from discord.ext import commands
from discord import app_commands
from config import connect, get_setting, set_setting

class TicketView(discord.ui.View):
    def __init__(self): super().__init__(timeout=None)

    @discord.ui.button(label="Create Support Ticket", emoji="🎫", style=discord.ButtonStyle.primary, custom_id="bloomcraft:create_ticket")
    async def create_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        guild = interaction.guild
        existing = discord.utils.get(guild.text_channels, name=f"ticket-{interaction.user.id}")
        if existing:
            return await interaction.response.send_message(f"You already have a ticket: {existing.mention}", ephemeral=True)
        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
            guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)
        }
        staff_role_id = get_setting(guild.id, "ticket_staff_role")
        if staff_role_id:
            role = guild.get_role(int(staff_role_id))
            if role: overwrites[role] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)
        category = None
        cat_id = get_setting(guild.id, "ticket_category")
        if cat_id: category = guild.get_channel(int(cat_id))
        channel = await guild.create_text_channel(f"ticket-{interaction.user.id}", overwrites=overwrites, category=category)
        with connect() as db:
            db.execute("INSERT OR REPLACE INTO tickets(channel_id,guild_id,opener_id) VALUES(?,?,?)", (channel.id,guild.id,interaction.user.id))
        await channel.send(f"Hello {interaction.user.mention}! Staff will be with you soon.", view=CloseView())
        await interaction.response.send_message(f"Your ticket is ready: {channel.mention}", ephemeral=True)

class CloseView(discord.ui.View):
    def __init__(self): super().__init__(timeout=None)
    @discord.ui.button(label="Close Ticket", emoji="🔒", style=discord.ButtonStyle.danger, custom_id="bloomcraft:close_ticket")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        with connect() as db:
            row = db.execute("SELECT opener_id FROM tickets WHERE channel_id=?", (interaction.channel_id,)).fetchone()
        if not row: return await interaction.response.send_message("This is not a ticket channel.", ephemeral=True)
        is_staff = interaction.user.guild_permissions.manage_channels
        if interaction.user.id != row["opener_id"] and not is_staff:
            return await interaction.response.send_message("Only the ticket opener or staff can close this.", ephemeral=True)
        await interaction.response.send_message("🔒 Ticket will be deleted in 5 seconds.")
        await interaction.channel.delete(delay=5)
        with connect() as db: db.execute("DELETE FROM tickets WHERE channel_id=?", (interaction.channel_id,))

class Tickets(commands.Cog):
    def __init__(self, bot): self.bot = bot
    async def cog_load(self):
        self.bot.add_view(TicketView())
        self.bot.add_view(CloseView())

    @app_commands.command(name="ticketpanel", description="Post a ticket creation panel.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def ticketpanel(self, interaction: discord.Interaction):
        e = discord.Embed(title="🌸 BloomCraft Support", description="Need help? Open a private support ticket below.", color=0xF4A7C5)
        await interaction.channel.send(embed=e, view=TicketView())
        await interaction.response.send_message("Ticket panel posted.", ephemeral=True)

    @app_commands.command(name="setticketstaff", description="Set the support staff role.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setticketstaff(self, interaction: discord.Interaction, role: discord.Role):
        set_setting(interaction.guild_id, "ticket_staff_role", role.id)
        await interaction.response.send_message(f"Ticket staff role set to {role.mention}", ephemeral=True)

async def setup(bot): await bot.add_cog(Tickets(bot))
