import discord
from discord.ext import commands
from discord import app_commands
from config import get_setting, set_setting

class Minecraft(commands.Cog):
    def __init__(self, bot): self.bot = bot
    @app_commands.command(name="setmcserver", description="Set the Minecraft server address shown by /mcserver.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setmcserver(self, interaction: discord.Interaction, address: str, edition: str = "Java / Bedrock"):
        set_setting(interaction.guild_id, "mc_address", address)
        set_setting(interaction.guild_id, "mc_edition", edition)
        await interaction.response.send_message("🌸 Minecraft server details saved.", ephemeral=True)
    @app_commands.command(name="mcserver", description="Show Minecraft server connection details.")
    async def mcserver(self, interaction: discord.Interaction):
        address = get_setting(interaction.guild_id, "mc_address", "Not configured")
        edition = get_setting(interaction.guild_id, "mc_edition", "Java / Bedrock")
        e = discord.Embed(title="🌸 BloomCraft SMP", description=f"**Address:** `{address}`\n**Edition:** {edition}", color=0xF4A7C5)
        await interaction.response.send_message(embed=e)

async def setup(bot): await bot.add_cog(Minecraft(bot))
