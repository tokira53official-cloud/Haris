import discord
from discord.ext import commands
from config import get_setting

class Boosts(commands.Cog):
    def __init__(self, bot): self.bot = bot
    @commands.Cog.listener()
    async def on_member_update(self, before, after):
        if before.premium_since is None and after.premium_since is not None:
            channel_id = get_setting(after.guild.id, "boost_channel")
            channel = after.guild.get_channel(int(channel_id)) if channel_id else after.guild.system_channel
            if channel:
                await channel.send(f"💗 Thank you {after.mention} for boosting **{after.guild.name}**!")
async def setup(bot): await bot.add_cog(Boosts(bot))
