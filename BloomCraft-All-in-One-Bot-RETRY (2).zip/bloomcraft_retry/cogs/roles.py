import discord
from discord.ext import commands
from discord import app_commands
from config import get_setting, set_setting

class Roles(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="setautorole", description="Set a role automatically given to new members.")
    @app_commands.checks.has_permissions(manage_roles=True)
    async def setautorole(self, interaction: discord.Interaction, role: discord.Role):
        if role >= interaction.guild.me.top_role:
            return await interaction.response.send_message("Move the bot role above that role first.", ephemeral=True)
        set_setting(interaction.guild_id, "autorole", role.id)
        await interaction.response.send_message(f"Autorole set to {role.mention}.", ephemeral=True)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        rid = get_setting(member.guild.id, "autorole")
        role = member.guild.get_role(int(rid)) if rid else None
        if role and role < member.guild.me.top_role:
            try: await member.add_roles(role, reason="Configured autorole")
            except discord.HTTPException: pass

    @app_commands.command(name="addrole", description="Give a role to a member.")
    @app_commands.checks.has_permissions(manage_roles=True)
    async def addrole(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role):
        if role >= interaction.guild.me.top_role:
            return await interaction.response.send_message("The bot cannot manage that role. Check role hierarchy.", ephemeral=True)
        await member.add_roles(role, reason=f"Requested by {interaction.user}")
        await interaction.response.send_message(f"Added {role.mention} to {member.mention}.")

    @app_commands.command(name="removerole", description="Remove a role from a member.")
    @app_commands.checks.has_permissions(manage_roles=True)
    async def removerole(self, interaction: discord.Interaction, member: discord.Member, role: discord.Role):
        if role >= interaction.guild.me.top_role:
            return await interaction.response.send_message("The bot cannot manage that role. Check role hierarchy.", ephemeral=True)
        await member.remove_roles(role, reason=f"Requested by {interaction.user}")
        await interaction.response.send_message(f"Removed {role.mention} from {member.mention}.")

async def setup(bot): await bot.add_cog(Roles(bot))
