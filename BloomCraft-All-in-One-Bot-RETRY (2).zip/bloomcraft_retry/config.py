import os
import sqlite3

DB_PATH = os.getenv("DATABASE_PATH", "data/bloomcraft.db")
os.makedirs(os.path.dirname(DB_PATH) or ".", exist_ok=True)

def connect():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    with connect() as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS settings (
            guild_id INTEGER NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL,
            PRIMARY KEY (guild_id, key)
        );
        CREATE TABLE IF NOT EXISTS xp (
            guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, xp INTEGER DEFAULT 0,
            level INTEGER DEFAULT 0, PRIMARY KEY (guild_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS wallets (
            guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, coins INTEGER DEFAULT 0,
            PRIMARY KEY (guild_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS invites (
            guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, count INTEGER DEFAULT 0,
            PRIMARY KEY (guild_id, user_id)
        );
        CREATE TABLE IF NOT EXISTS tickets (
            channel_id INTEGER PRIMARY KEY, guild_id INTEGER NOT NULL, opener_id INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS player_stats (
            guild_id INTEGER NOT NULL, player_name TEXT NOT NULL, kills INTEGER DEFAULT 0,
            deaths INTEGER DEFAULT 0, hearts REAL DEFAULT 10,
            PRIMARY KEY (guild_id, player_name)
        );
        CREATE TABLE IF NOT EXISTS giveaways (
            message_id INTEGER PRIMARY KEY, guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL,
            prize TEXT NOT NULL, ends_at INTEGER NOT NULL
        );
        """)

def get_setting(guild_id, key, default=None):
    with connect() as db:
        row = db.execute("SELECT value FROM settings WHERE guild_id=? AND key=?", (guild_id, key)).fetchone()
        return row["value"] if row else default

def set_setting(guild_id, key, value):
    with connect() as db:
        db.execute("""INSERT INTO settings(guild_id,key,value) VALUES(?,?,?)
        ON CONFLICT(guild_id,key) DO UPDATE SET value=excluded.value""",
        (guild_id, key, str(value)))

init_db()
