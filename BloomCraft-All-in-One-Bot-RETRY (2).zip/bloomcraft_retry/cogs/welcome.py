import discord
from discord.ext import commands
from discord import app_commands
from config import get_setting, set_setting

class Welcome(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="setwelcome", description="Set the welcome channel for this server.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setwelcome(self, interaction: discord.Interaction, channel: discord.TextChannel):
        set_setting(interaction.guild_id, "welcome_channel", channel.id)
        await interaction.response.send_message(f"🌸 Welcome channel set to {channel.mention}", ephemeral=True)

    @commands.Cog.listener()
    async def on_member_join(self, member):
        channel_id = get_setting(member.guild.id, "welcome_channel")
        if not channel_id: return
        channel = member.guild.get_channel(int(channel_id))
        if channel:
            e = discord.Embed(
                title="🌸 Welcome to BloomCraft!",
                description=f"Welcome {member.mention}!\nYou are member **#{member.guild.member_count}**.",
                color=0xF4A7C5
            )
            e.set_thumbnail(url=member.display_avatar.url)
            await channel.send(embed=e)

async def setup(bot): await bot.add_cog(Welcome(bot))
