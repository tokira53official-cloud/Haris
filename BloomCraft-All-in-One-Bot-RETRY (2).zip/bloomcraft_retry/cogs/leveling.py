import random
import discord
from discord.ext import commands
from discord import app_commands
from config import connect

class Leveling(commands.Cog):
    def __init__(self, bot): self.bot = bot
    @commands.Cog.listener()
    async def on_message(self, message):
        if not message.guild or message.author.bot: return
        with connect() as db:
            row = db.execute("SELECT xp,level FROM xp WHERE guild_id=? AND user_id=?", (message.guild.id,message.author.id)).fetchone()
            xp = (row["xp"] if row else 0) + random.randint(15,25)
            level = int((xp / 100) ** 0.5)
            db.execute("""INSERT INTO xp(guild_id,user_id,xp,level) VALUES(?,?,?,?)
            ON CONFLICT(guild_id,user_id) DO UPDATE SET xp=excluded.xp,level=excluded.level""",
            (message.guild.id,message.author.id,xp,level))
        if level > (row["level"] if row else 0):
            await message.channel.send(f"🌸 {message.author.mention} reached level **{level}**!")
    @app_commands.command(name="rank", description="Check your level and XP.")
    async def rank(self, interaction: discord.Interaction, member: discord.Member = None):
        member = member or interaction.user
        with connect() as db:
            row = db.execute("SELECT xp,level FROM xp WHERE guild_id=? AND user_id=?", (interaction.guild_id,member.id)).fetchone()
        e = discord.Embed(title=f"🌸 {member.display_name}'s Rank", color=0xF4A7C5)
        e.add_field(name="Level", value=row["level"] if row else 0)
        e.add_field(name="XP", value=row["xp"] if row else 0)
        await interaction.response.send_message(embed=e)

async def setup(bot): await bot.add_cog(Leveling(bot))
