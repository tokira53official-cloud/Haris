import asyncio
import discord
from discord.ext import commands
from discord import app_commands
import yt_dlp

YDL_OPTIONS = {"format": "bestaudio/best", "quiet": True, "noplaylist": True, "default_search": "ytsearch"}
FFMPEG_OPTIONS = {"before_options": "-reconnect 1 -reconnect_streamed 1 -reconnect_delay_max 5",
                  "options": "-vn"}

class Music(commands.Cog):
    """Basic voice playback. Requires FFmpeg and PyNaCl installed on the host."""
    def __init__(self, bot):
        self.bot = bot
        self.queues = {}

    async def extract(self, query):
        loop = asyncio.get_running_loop()
        def run():
            with yt_dlp.YoutubeDL(YDL_OPTIONS) as ydl:
                info = ydl.extract_info(query, download=False)
                if "entries" in info: info = next((x for x in info["entries"] if x), None)
                if not info: raise ValueError("No playable result found.")
                return {"url": info["url"], "title": info.get("title", "Unknown track"), "webpage": info.get("webpage_url", query)}
        return await loop.run_in_executor(None, run)

    async def play_next(self, guild):
        q = self.queues.get(guild.id, [])
        if not q: return
        item = q.pop(0)
        voice = guild.voice_client
        if not voice: return
        source = discord.FFmpegPCMAudio(item["url"], **FFMPEG_OPTIONS)
        voice.play(source, after=lambda error: asyncio.run_coroutine_threadsafe(self.play_next(guild), self.bot.loop))
        self.queues[guild.id] = q

    @app_commands.command(name="join", description="Join your voice channel.")
    async def join(self, interaction: discord.Interaction):
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.response.send_message("Join a voice channel first.", ephemeral=True)
        await interaction.user.voice.channel.connect()
        await interaction.response.send_message(f"Joined {interaction.user.voice.channel.mention}.")

    @app_commands.command(name="play", description="Play a song by search text or URL.")
    async def play(self, interaction: discord.Interaction, query: str):
        await interaction.response.defer()
        if not interaction.user.voice or not interaction.user.voice.channel:
            return await interaction.followup.send("Join a voice channel first.")
        voice = interaction.guild.voice_client
        if not voice: voice = await interaction.user.voice.channel.connect()
        try: item = await self.extract(query)
        except Exception as exc: return await interaction.followup.send(f"Could not find audio: {str(exc)[:300]}")
        q = self.queues.setdefault(interaction.guild_id, [])
        q.append(item)
        if not voice.is_playing() and not voice.is_paused():
            await self.play_next(interaction.guild)
            await interaction.followup.send(f"▶️ Now playing: **{item['title']}**")
        else:
            await interaction.followup.send(f"Added to queue: **{item['title']}**")

    @app_commands.command(name="skip", description="Skip the current track.")
    async def skip(self, interaction: discord.Interaction):
        voice = interaction.guild.voice_client
        if not voice or not voice.is_playing(): return await interaction.response.send_message("Nothing is playing.", ephemeral=True)
        voice.stop()
        await interaction.response.send_message("⏭️ Skipped.")

    @app_commands.command(name="pause", description="Pause playback.")
    async def pause(self, interaction: discord.Interaction):
        voice = interaction.guild.voice_client
        if voice and voice.is_playing():
            voice.pause(); return await interaction.response.send_message("⏸️ Paused.")
        await interaction.response.send_message("Nothing is playing.", ephemeral=True)

    @app_commands.command(name="resume", description="Resume playback.")
    async def resume(self, interaction: discord.Interaction):
        voice = interaction.guild.voice_client
        if voice and voice.is_paused():
            voice.resume(); return await interaction.response.send_message("▶️ Resumed.")
        await interaction.response.send_message("Playback is not paused.", ephemeral=True)

    @app_commands.command(name="stop", description="Stop music and clear the queue.")
    async def stop(self, interaction: discord.Interaction):
        voice = interaction.guild.voice_client
        self.queues[interaction.guild_id] = []
        if voice:
            await voice.disconnect()
        await interaction.response.send_message("⏹️ Stopped and cleared the queue.")

    @app_commands.command(name="queue", description="Show the upcoming tracks.")
    async def queue(self, interaction: discord.Interaction):
        q = self.queues.get(interaction.guild_id, [])
        if not q: return await interaction.response.send_message("The queue is empty.")
        await interaction.response.send_message("\n".join(f"{i}. {x['title']}" for i,x in enumerate(q[:15],1)))

async def setup(bot): await bot.add_cog(Music(bot))
