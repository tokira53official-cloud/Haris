import discord
from discord.ext import commands
from discord import app_commands
from config import connect

class Lifesteal(commands.Cog):
    def __init__(self, bot): self.bot = bot
    @app_commands.command(name="setstats", description="Staff: set a Minecraft player's Lifesteal stats.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setstats(self, interaction: discord.Interaction, player: str, kills: int, deaths: int, hearts: app_commands.Range[float,0,100]):
        with connect() as db:
            db.execute("""INSERT INTO player_stats(guild_id,player_name,kills,deaths,hearts) VALUES(?,?,?,?,?)
            ON CONFLICT(guild_id,player_name) DO UPDATE SET kills=excluded.kills,deaths=excluded.deaths,hearts=excluded.hearts""",
            (interaction.guild_id,player,kills,deaths,hearts))
        await interaction.response.send_message(f"🌸 Updated stats for **{player}**.")
    @app_commands.command(name="playerstats", description="View a Minecraft player's saved Lifesteal stats.")
    async def playerstats(self, interaction: discord.Interaction, player: str):
        with connect() as db:
            row = db.execute("SELECT * FROM player_stats WHERE guild_id=? AND player_name=?", (interaction.guild_id,player)).fetchone()
        if not row: return await interaction.response.send_message("Player not found. Staff can add stats with /setstats.")
        e = discord.Embed(title=f"❤️ {player} — Lifesteal Stats", color=0xF4A7C5)
        e.add_field(name="Kills", value=row["kills"])
        e.add_field(name="Deaths", value=row["deaths"])
        e.add_field(name="Hearts", value=row["hearts"])
        await interaction.response.send_message(embed=e)

async def setup(bot): await bot.add_cog(Lifesteal(bot))
