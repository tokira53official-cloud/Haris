import random
import discord
from discord.ext import commands
from discord import app_commands

class Giveaways(commands.Cog):
    def __init__(self, bot): self.bot = bot
    @app_commands.command(name="giveaway", description="Create a simple reaction-entry giveaway.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def giveaway(self, interaction: discord.Interaction, duration_minutes: app_commands.Range[int,1,10080], prize: str):
        await interaction.response.defer()
        e = discord.Embed(title="🎉 Giveaway!", description=f"Prize: **{prize}**\nReact with 🎉 to enter.\nEnds in {duration_minutes} minutes.", color=0xF4A7C5)
        msg = await interaction.channel.send(embed=e)
        await msg.add_reaction("🎉")
        await interaction.followup.send(f"Giveaway created: {msg.jump_url}", ephemeral=True)
        await discord.utils.sleep_until(discord.utils.utcnow() + __import__("datetime").timedelta(minutes=duration_minutes))
        try:
            msg = await interaction.channel.fetch_message(msg.id)
            users = [u async for u in msg.reactions[0].users() if not u.bot]
            if users:
                winner = random.choice(users)
                await interaction.channel.send(f"🎊 Congratulations {winner.mention}! You won **{prize}**!")
            else:
                await interaction.channel.send("No valid entries. Giveaway ended with no winner.")
        except discord.HTTPException: pass

async def setup(bot): await bot.add_cog(Giveaways(bot))
