import discord
from discord.ext import commands
from discord import app_commands
from config import get_setting, set_setting

class Community(commands.Cog):
    def __init__(self, bot): self.bot = bot

    @app_commands.command(name="suggest", description="Submit a suggestion to the configured suggestion channel.")
    async def suggest(self, interaction: discord.Interaction, suggestion: str):
        cid = get_setting(interaction.guild_id, "suggestion_channel")
        channel = interaction.guild.get_channel(int(cid)) if cid else None
        if not channel:
            return await interaction.response.send_message("Suggestions are not configured. Ask an admin to use /setsuggestions.", ephemeral=True)
        e = discord.Embed(title="💡 New Suggestion", description=suggestion[:3500], color=0xF4A7C5)
        e.set_author(name=str(interaction.user), icon_url=interaction.user.display_avatar.url)
        msg = await channel.send(embed=e)
        for emoji in ("👍", "👎"): await msg.add_reaction(emoji)
        await interaction.response.send_message("Your suggestion was submitted. Thank you!", ephemeral=True)

    @app_commands.command(name="setsuggestions", description="Set the suggestion channel.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def setsuggestions(self, interaction: discord.Interaction, channel: discord.TextChannel):
        set_setting(interaction.guild_id, "suggestion_channel", channel.id)
        await interaction.response.send_message(f"Suggestion channel set to {channel.mention}.", ephemeral=True)

    @app_commands.command(name="poll", description="Create a simple yes/no poll.")
    @app_commands.checks.has_permissions(manage_messages=True)
    async def poll(self, interaction: discord.Interaction, question: str):
        e = discord.Embed(title="📊 Poll", description=question[:3500], color=0xF4A7C5)
        msg = await interaction.channel.send(embed=e)
        await msg.add_reaction("👍")
        await msg.add_reaction("👎")
        await interaction.response.send_message(f"Poll created: {msg.jump_url}", ephemeral=True)

    @app_commands.command(name="announce", description="Post a BloomCraft-style announcement.")
    @app_commands.checks.has_permissions(manage_guild=True)
    async def announce(self, interaction: discord.Interaction, channel: discord.TextChannel, title: str, message: str):
        e = discord.Embed(title=f"🌸 {title}", description=message[:4000], color=0xF4A7C5)
        e.set_footer(text=f"{interaction.guild.name} • Announcement")
        await channel.send(embed=e)
        await interaction.response.send_message(f"Announcement posted in {channel.mention}.", ephemeral=True)

async def setup(bot): await bot.add_cog(Community(bot))
