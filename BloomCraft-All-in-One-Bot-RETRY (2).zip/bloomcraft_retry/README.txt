BLOOMCRAFT BOT — EXPANDED MULTI-SERVER PYTHON PROJECT
====================================================

This is an expanded, modular Discord bot project. It is designed to be
invited to multiple servers. Guild settings and stored stats are separated
by guild ID in SQLite. BloomCraft pink/cherry-blossom embeds are the default.

Included modules and commands
-----------------------------
General:
  /ping /serverinfo /userinfo

Moderation:
  /kick /ban /timeout /purge

Welcome and roles:
  /setwelcome /setautorole /addrole /removerole

Tickets:
  /ticketpanel /setticketstaff
  Ticket creation and close buttons

Leveling:
  /rank

Economy:
  /balance /daily /pay

Invites:
  /invites

Minecraft / Lifesteal:
  /setmcserver /mcserver /setstats /playerstats

Community:
  /suggest /setsuggestions /poll /announce

Logs:
  /setlogs (message delete/edit and member leave logs)

Giveaways:
  /giveaway

Music:
  /join /play /skip /pause /resume /stop /queue

Boosts:
  Booster thank-you announcement (uses configured log channel or system channel)

IMPORTANT LIMITATIONS / SETUP NOTES
-----------------------------------
This is a feature-rich starter implementation, not an exact clone of Arcane,
Booster Bot, Ticket Tool, Invite Tracker, Falcon, Mimu, Wave or Dyno.
Some advanced systems still need production hardening and configuration:
- Music needs FFmpeg installed on the host and voice support (PyNaCl).
  Audio extraction can break when external providers change; a Lavalink
  backend is recommended for a production public bot.
- Minecraft stats are manually maintained with /setstats. Live server
  integration needs a compatible Minecraft plugin/API or RCON bridge.
- Invite tracking requires Manage Server permission and may be affected by
  vanity invites, invite permissions, and Discord API limitations.
- Economy daily rewards currently need a cooldown upgrade before public use.
- Giveaway command is a basic reaction-entry implementation; run tests and
  improve persistent scheduling before relying on it.
- Add a persistent moderation case system, anti-raid thresholds, advanced
  automod, transcript export, button-based reaction-role panel, staff
  applications, verification flow, and production monitoring before public
  launch. Do not advertise these as completed until implemented and tested.

INSTALL
-------
1. Extract the ZIP.
2. Use Python 3.10+.
3. Copy .env.example to .env.
4. Put your bot token in .env as DISCORD_TOKEN=YOUR_TOKEN.
5. Install:
      python -m pip install -r requirements.txt
6. Ensure FFmpeg is installed and available as `ffmpeg` for music.
7. Run:
      python bot.py

DISCORD DEVELOPER PORTAL
------------------------
Enable Server Members Intent and Message Content Intent under Bot settings.
Invite using OAuth2 URL Generator:
  Scopes: bot, applications.commands
Give only required permissions. Suggested permissions for the listed
modules include View Channels, Send Messages, Embed Links, Read Message
History, Add Reactions, Manage Messages, Kick Members, Ban Members,
Moderate Members, Manage Channels, Manage Roles and Manage Server.
Place the bot role above roles it must manage.

SECURITY
--------
Never share your bot token. Keep it in .env, not in source code or screenshots.
Do not give the bot Administrator unless you have a specific reason.
Test in a private server first. Back up data/bloomcraft.db.
